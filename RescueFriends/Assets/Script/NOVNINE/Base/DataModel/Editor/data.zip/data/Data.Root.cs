﻿#if !USE_DLLDATACLASS

using JsonFx.Json;
using ProtoBuf;

namespace Data {

    public class SaveData {
        public bool enableSound = true;
    }

    [ProtoContract]
    public class GameData : ContextHolder<SaveData> {
        [ProtoMember(100)] public string key;

        [ProtoMember(1)] public string dataString;
        [ProtoMember(2)] public int dataInt;
    }

	[ProtoContract]	
    public class Root {
        [ProtoMember(1)]
        public GameData gameData;
    }

}

#endif
